# -*- coding: utf-8 -*-
# czifile/__main__.py

"""Czifile package command line script."""

import sys

from .czifile import main

sys.exit(main())
